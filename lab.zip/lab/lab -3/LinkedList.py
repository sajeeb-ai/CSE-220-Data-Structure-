class Node:
  def __init__(self, e = None, n = None):
    self.element = e
    self.next = n


class LinkedList:
  
  def __init__(self, a):
      self.head = None
      if type(a) == list:
          for i in a: # a = [99, 1, 2, 3, 4, 5]
              if self.head == None:
                 self.head = Node(i)   #Node(99)
                 cur_Node = self.head
              else:
                  cur_Node.next = Node(i)
                  cur_Node = cur_Node.next

  def countNode(self):
     count = 0
     cur_Node = self.head
     while cur_Node != None:
         count += 1
         cur_Node = cur_Node.next
     return count

  def printList(self):
     cur_node = self.head
     while cur_node != None:
         print(cur_node.element, end=" ")
         cur_node = cur_node.next
     print()
         
  def nodeAt(self, idx): 
     curIndex = 0
     curNode = self.head
     while curIndex != idx and curNode != None:
         curIndex += 1
         curNode = curNode.next
     return curNode
  
  def get(self, idx):
     curIndex = 0
     curNode = self.head
     while curIndex != idx and curNode != None:
         curIndex += 1
         curNode = curNode.next
     return curNode.element
  
    
  def set(self, idx, elem): # 99 100 2 3
    curIndex = 0
    curNode = self.head
    while curIndex != idx and curNode != None:
        curIndex += 1
        curNode = curNode.next
    
    if curIndex != idx:
        return None
    prevElem = curNode.element
    curNode.element = elem
    return prevElem

  def indexOf(self, elem): # 99  1  5   7
    curNode = self.head
    idx = 0 # 1  2
    while curNode.element != elem and curNode != None:
        idx += 1
        curNode = curNode.next
    if curNode.element == None:
        return -1
    else:
        return idx
        
  def contains(self, elem):
    curNode = self.head
    while curNode.element != elem:
        curNode = curNode.next
    if curNode.element == elem:
        return True
    else:
        return False

  def copyList(self): 
    a = []
    curNode = self.head
    while curNode != None:
        a.append(curNode.element)
        curNode = curNode.next
    return a

  def reverseList(self):
    a = self.copyList()
    b = []
    for i in range(len(a)-1, -1, -1):
        b.append(a[i])
    return b
  
  def insert(self, elem, idx): #  90 100 5 200
    curNode = self.head
    curIdx = 0
    if idx == 0:
        curNode = self.head
        self.head = Node(elem, curNode)
        return
    while idx != curIdx and curNode != None:
        curIdx += 1
        prev = curNode
        curNode = curNode.next
    if curIdx < idx:
        return None
    else:
        prev.next = Node(elem, curNode)

  def remove(self, idx):
    curNode = self.head
    curIdx = 0
    if idx == 0:
        val = self.head.element
        self.head = self.head.next
        return val
    while idx != curIdx and curNode != None:
        curIdx += 1
        prev = curNode
        curNode = curNode.next
    if curIdx < idx:
        return None
    else:
        val = curNode.element
        prev.next = curNode.next
        return val

  #  1 2 3
  def rotateLeft(self):   
    val = self.head.element
    self.remove(0)
    self.insert(val, self.countNode())
  
  def rotateRight(self):
    val = self.get(self.countNode()-1)
    self.remove(self.countNode()-1)
    self.insert(val, 0)


print("////// Test 01 //////")
a1 = [10, 20, 30, 40]
h1 = LinkedList(a1) # Creates a linked list using the values from the array
# head will refer to the Node that contains the element from a[0]

h1.printList() # This should print: 10,20,30,40
print(h1.countNode()) # This should print: 4

print("////// Test 02 //////")
# returns the reference of the Node at the given index. For invalid idx return None.
myNode = h1.nodeAt(1)
print(myNode.element) # This should print: 20. In case of invalid index This will generate an Error.
    
print("////// Test 03 //////")
# returns the element of the Node at the given index. For invalid idx return None.
val = h1.get(2)
print(val) # This should print: 30. In case of invalid index This will print None.
    
    
print("////// Test 04 //////")
    
# updates the element of the Node at the given index. 
# Returns the old element that was replaced. For invalid index return None.
# parameter: index, element
         
print(h1.set(1,85)) # This should print: 20
h1.printList() # This should print: 10,85,30,40.
print(h1.set(15,85)) # This should print: None
h1.printList() # This should print: 10,85,30,40. 
    
print("////// Test 05 //////")
# returns the index of the Node containing the given element.
# if the element does not exist in the List, return -1.
index = h1.indexOf(40)
print(index) # This should print: 3. In case of element that doesn't exists in the list this will print -1.
    
print("////// Test 06 //////")
# returns true if the element exists in the List, return false otherwise.
ask = h1.contains(40)
print(ask) # This should print: True.
    
    
print("////// Test 07 //////")
a2 = [10,20,30,40,50,60,70]
h2 = LinkedList(a2) # uses theconstructor where a is an built in list
h2.printList() # This should print: 10,20,30,40,50,60,70.  
# Makes a duplicate copy of the given List. Returns the head reference of the duplicate list.
copyH=h2.copyList() # Head node reference of the duplicate list
h3 = LinkedList(copyH) # uses the constructor where a is head of a linkedlist 
h3.printList() # This should print: 10,20,30,40,50,60,70.  
    
print("////// Test 08 //////")
a4 = [10,20,30,40,50]
h4 = LinkedList(a4) # uses theconstructor where a is an built in list
h4.printList() # This should print: 10,20,30,40,50.  
# Makes a reversed copy of the given List. Returns the head reference of the reversed list.
revH=h4.reverseList() # Head node reference of the reversed list
h5 = LinkedList(revH) # uses the constructor where a is head of a linkedlist 
h5.printList() # This should print: 50,40,30,20,10.  
    
print("////// Test 09 //////")
a6 = [10,20,30,40]
h6 = LinkedList(a6) # uses theconstructor where a is an built in list
h6.printList() # This should print: 10,20,30,40.  
    
# inserts Node containing the given element at the given index. Check validity of index.
h6.insert(85,0)
h6.printList() # This should print: 85,10,20,30,40.  
h6.insert(95,3)
h6.printList() # This should print: 85,10,20,95,30,40.  
h6.insert(75,6)
h6.printList() # This should print: 85,10,20,95,30,40,75. 
    
    
    
print("////// Test 10 //////")
a7 = [10,20,30,40,50,60,70]
h7 = LinkedList(a7) # uses theconstructor where a is an built in list
h7.printList() # This should print: 10,20,30,40,50,60,70.  
    
# removes Node at the given index. returns element of the removed node.
# Check validity of index. return None if index is invalid.
    
print("Removed element:",h7.remove(0)) # This should print: Removed element: 10
h7.printList() # This should print: 20,30,40,50,60,70.  
print("Removed element: ",h7.remove(3)) # This should print: Removed element: 50
h7.printList() # This should print: 20,30,40,60,70.  
print("Removed element: ",h7.remove(4)) # This should print: Removed element: 70
h7.printList() # This should print: 20,30,40,60. 
    
    
print("////// Test 11 //////")
a8 = [10,20,30,40]
h8 = LinkedList(a8) # uses theconstructor where a is an built in list
h8.printList() # This should print: 10,20,30,40.  
    
# Rotates the list to the left by 1 position.
h8.rotateLeft()
h8.printList() # This should print: 20,30,40,10.  
    
    
print("////// Test 12 //////")
a9 = [10,20,30,40]
h9 = LinkedList(a9) # uses theconstructor where a is an built in list
h9.printList() # This should print: 10,20,30,40.  
    
# Rotates the list to the right by 1 position.
h9.rotateRight()
h9.printList() # This should print: 40,10,20,30.





