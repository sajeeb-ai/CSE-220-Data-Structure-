def powerfun(base,n):
    if n <= 1:
        return base
    else:
        return base**n

print(powerfun(3,3))