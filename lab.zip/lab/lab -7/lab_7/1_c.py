def myfun(arr, i):
    if i >= len(arr) - 1:
        print(arr[i])
    else:
        print(arr[i])
        myfun(arr, i+1)

arr = [10,20,30,40,50]
myfun(arr,0)