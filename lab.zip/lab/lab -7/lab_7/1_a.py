def facto(n):
  if n < 2:
    return n
  else:
    return n * facto(n-1)

print(facto(15))